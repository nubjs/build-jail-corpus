# sharp@0.34.5 — BROKEN-IN-ENVIRONMENT

- record: `/Users/colinmcd94/.cache/nub/worktrees/integ/tests/build-jail-search/results/runs/darwin-arm64/sharp/0.34.5/results.json`
- measured: 2026-08-02T10:00:12.162Z on darwin-arm64, node v26.5.0
- harness `25124760`, nub `938a7333` (v0.6.0)

## Verdict

**BROKEN-IN-ENVIRONMENT** — a reference PM fails too — grant nothing, and suspect this host

## Did the fixture actually install?

- control: rc 1, **3458 files**, materialized `true`
- declares an install script: `true` (read from the TARBALL manifest, not the packument)

## First error, per arm

### `control-repeat-`  (944 bytes)
`/Users/colinmcd94/.cache/nub/worktrees/integ/tests/build-jail-search/results/runs/darwin-arm64/sharp/0.34.5/control-repeat-.log`
```
× lifecycle script install failed for sharp@0.34.5: script `install` exited
```

### `control-tested-pkg-everything-`  (599 bytes)
`/Users/colinmcd94/.cache/nub/worktrees/integ/tests/build-jail-search/results/runs/darwin-arm64/sharp/0.34.5/control-tested-pkg-everything-.log`
```
× lifecycle script install failed for sharp@0.34.5: script `install` exited
```

## Reference PMs

- **npm**: rc `1`, signature `npm error code 1`
  - ⚠ npm 11.17+ SKIPS a dependency's install script unless covered by `allowScripts`
    (`arborist/lib/arborist/rebuild.js`), so rc 0 may mean NO SCRIPT RAN.
  - ⚠ npm BUFFERS script output unless `--foreground-scripts`, so its log shows npm's
    wrapper error rather than the script's own. Its full debug log is `$HOME/.npm/_logs/*-debug-0.log`.
- **pnpm**: rc `1`, signature `{"time":<hash>,"hostname":"MacBookPro.lan","pid":85882,"level":"debug","name":"pnpm:skipped-optional-dependency","details":"Error: Unsupported platform for @img`
  - lifecycle events:
    - `install` exit `—`
    - `install` exit `—`: > sharp@0.34.5 build
    - `install` exit `—`: > node install/build.js
    - `install` exit `—`: sharp: Attempting to build from source via node-gyp
    - `install` exit `—`: sharp: See https://sharp.pixelplumbing.com/install#building-from-source
    - `install` exit `—`: sharp: Please add node-addon-api to your dependencies
  - ⚠ pnpm gates scripts behind `onlyBuiltDependencies`; `--reporter=ndjson` gives per-event records.
- signatures matched: `false`
- standing: published 2025-11-06T14:19:40.989Z, 268d old, 81906296/wk, latest `0.35.3`
- ⛔ needsInvestigation: npm ALSO fails, but this is 268d old with 81906296 weekly downloads — people install it successfully every week, so suspect a missing toolchain on the measuring host before accepting the dismissal

## The walk

| # | state | cost | pass | rc | files |
|---|---|---|---|---|---|
| ctl | `CONTROL (tested pkg: everything; all others: everything)` | — | ✗ | 1 | 3458 |

